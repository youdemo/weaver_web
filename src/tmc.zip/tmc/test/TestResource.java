package tmc.test;

public class TestResource {

	public static void main(String[] args) {
		tmc.org.HrmResourceBean hrb = new tmc.org.HrmResourceBean();
		
		hrb.setWorkcode("");
		hrb.setLoginid("");
		hrb.setLastname("");
		hrb.setPassword("");
		hrb.setDeptIdOrCode(0);
		hrb.setDepartmentid("");
		hrb.setDepartmentCode("");
		hrb.setJobIdOrCode(0);
		hrb.setJobtitle("");
		hrb.setJobtitleCode("");
		hrb.setManagerIdOrCode(0);
		hrb.setManagerid("");
		hrb.setManagerCode("");
		hrb.setSeclevel(10);
		
	}
}
